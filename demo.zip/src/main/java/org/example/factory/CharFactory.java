package org.example.factory;

public interface CharFactory {

    public String process(String input);
}
