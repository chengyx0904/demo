package org.example;

import org.example.factory.CharFactory;

public class RemoveConsecutiveChars implements CharFactory {
    @Override
    public String process(String input) {
        if (input == null || input.length() < 3) {
            return input;
        }

        StringBuilder sb = new StringBuilder(input);

        int pointer = 1;
        int counter = 1;

        while (pointer < sb.length()) {
            if (sb.charAt(pointer) == sb.charAt(pointer - 1)) {
                counter++;
            } else {
                if (counter >= 3) {
                    sb.delete(pointer - counter, pointer);
                    pointer -= counter;
                }
                counter = 1;
            }
            pointer++;
        }

        if(input.length() != sb.length() && sb.length() >= 3){
            return process(sb.toString());
        }

        return sb.toString();
    }
}
