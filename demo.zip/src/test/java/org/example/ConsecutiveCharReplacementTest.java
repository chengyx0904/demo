package org.example;

import org.example.factory.CharFactory;
import org.junit.Test;

import static org.junit.Assert.*;

public class ConsecutiveCharReplacementTest {

    @Test
    public void process() {
        CharFactory c = new ConsecutiveCharReplacement();

        assertEquals("d", c.process("abcccbad"));
        assertEquals("d", c.process("abccccbad"));
        assertEquals("d", c.process("aabccccbad"));
        assertEquals("aabbccdd", c.process("aabbccdd"));
    }
}