package org.example;

import org.example.factory.CharFactory;
import org.junit.Test;

import static org.junit.Assert.*;

public class RemoveConsecutiveCharsTest {

    @Test
    public void process() {
        CharFactory c = new RemoveConsecutiveChars();

        assertEquals("d", c.process("aabcccbbad"));
        assertEquals("d", c.process("aabccccbbad"));
        assertEquals("aabbccdd", c.process("aabbccdd"));
    }
}